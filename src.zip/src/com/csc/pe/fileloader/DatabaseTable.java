/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.csc.pe.fileloader;

import com.csc.pe.utils.data.DatabaseSession;
import com.csc.pe.utils.system.Logger;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author CClose
 */
public class DatabaseTable {
    public enum FormatType {
        Date(true),
        Time(true),
        Timestamp(true);

        private boolean isDate = false;

        public boolean isDate() {
            return this.isDate;
        }
        private FormatType(boolean isDate) {
            this.isDate = isDate;
        }
    }
    private DatabaseSession  session        = null;
    private Logger           log            = new Logger();
    private String           table          = null;
    private String           schema         = null;
    private ResultSet        insert         = null;
    private boolean          strongType     = true;
    private int              rowCount       = 0;
    private int              firstTimeField = -1;
    private SimpleDateFormat fmtDate        = new SimpleDateFormat("dd-MMM-yy HH:mm:ss");

    private class Column {
        String     name       = null;
        String     alias      = null;
        String     defValue   = null;
        String     inFormat   = null;
        FormatType formatType = null;
        Date       minTime    = null;
        Date       maxTime    = null;

        int    index    = -1;
        int    type     = -1;

        Column(String name, String alias) {
            this.name  = name;
            this.alias = alias;
        }
        
        Column(String name) {
            this(name, name);
        }
        void setValue(String value) throws SQLException {
            try {
                if (value == null || value.trim().length() == 0 || value.equalsIgnoreCase("null")) return;
                if (formatType == FormatType.Date && inFormat != null) {
                    Date timestamp = new SimpleDateFormat(inFormat).parse(value);
                    value = fmtDate.format(timestamp);

                    if (minTime == null || minTime.after(timestamp))  minTime = timestamp;
                    if (maxTime == null || maxTime.before(timestamp)) maxTime = timestamp;
                }
                if (strongType) {
                    value = value.trim();

                    switch (type) {
                        case java.sql.Types.INTEGER:
                            insert.updateInt(index, Integer.parseInt(value));
                            break;
                        case java.sql.Types.TIMESTAMP:
                            insert.updateTimestamp(index, new java.sql.Timestamp(fmtDate.parse(value).getTime()));
                            break;
                        case java.sql.Types.DATE:
                            insert.updateDate(index, new java.sql.Date(fmtDate.parse(value).getTime()));
                            break;
                        case java.sql.Types.TIME:
                            insert.updateTime(index, new java.sql.Time(fmtDate.parse(value).getTime()));
                            break;
                        case java.sql.Types.DOUBLE:
                            insert.updateDouble(index, Double.parseDouble(value));
                            break;
                        default:
                            insert.updateString(index, value);
                    }
                } else {
                    insert.updateString(index, value);
                }
            } catch (Exception ex) {
                throw new SQLException("Unable to convert " + value + " to SQL type " + type + " for " + table + '.' + name);
            }
        }
        java.sql.Timestamp getMinTime() {
            return minTime == null? null : new java.sql.Timestamp(minTime.getTime());
        }
        java.sql.Timestamp getMaxTime() {
            return maxTime == null? null : new java.sql.Timestamp(maxTime.getTime());
        }
    }
    private ArrayList<Column> columns = new ArrayList<Column>();
    
    public void setSession(DatabaseSession session) {
        this.session = session;
        strongType   = this.session.requiresStrongType();
    }
    public DatabaseSession getSession() {
        return session;
    }
    public void setLog(Logger log) {
        this.log = log;
    }
    public void setTable(String schema, String name) throws SQLException {
        columns.clear();
        this.table  = name;
        this.schema = schema;
        insert = session.updateQuery("SELECT * FROM " + getQualifiedTable() + " WHERE 1 = 0");
    }
    public void setTable(String name) throws SQLException {
        setTable(null, name);
    }
    public String getQualifiedTable(String name) {
        return schema == null || schema.isEmpty()? '"' + name + '"' : '"' + schema + "\".\"" + name + '"';
    }
    public String getQualifiedTable() {
        return getQualifiedTable(table);
    }
    public String getTable() {
        return table;
    }
    public int getColumnCount() {
        return columns.size();
    }
    public int getRowCount() {
        return rowCount;
    }
    public void open() {
        rowCount = 0;

        for (Column column : columns) {
            column.minTime = null;
            column.maxTime = null;
        }
    }
    private int getIndex(String name, boolean isAlias, boolean mustExist) {
        for (int i = 0; i < columns.size(); i++) {
            if (isAlias  && columns.get(i).alias.equals(name)) return i;
            if (!isAlias && columns.get(i).name.equals(name))  return i;
        }
        if (mustExist) {
            
            if (isAlias)
                log.fatalError("Alias " + name + " not enabled for table " + table);
            else
                log.fatalError("Column " + name + " not enabled for table " + table);
        }
        return -1;
    }
    public int getColumnIndex(String name) {
        return getIndex(name, false, false);
    }
    public int getAliasIndex(String name) {
        return getIndex(name, true, false);
    }
    public int setColumn(String name, String alias) throws SQLException {
        int index = getColumnIndex(name);

        if (index == -1) {
            Column c = new Column(name);

            c.index = insert.findColumn(name);
            c.type  = insert.getMetaData().getColumnType(c.index);
            c.alias = alias;
            columns.add(c);
            index = columns.size() - 1;
        } else
            columns.get(index).alias = alias;

        return index;
    }
    public void setColumns(File file) throws FileNotFoundException, IOException, SQLException {
        BufferedReader cols  = new BufferedReader(new FileReader(file));
        String         line  = null;
        int            count = 0;

        while ((line = cols.readLine()) != null) {
            count++;

            if (!line.trim().isEmpty()) {
                String name  = line;
                String value = null;
                int    i     = line.indexOf('=');

                if (i != -1) {
                    value = line.substring(i + 1);
                    name  = line.substring(0, i);

                    if (value.equalsIgnoreCase("!StartTimestamp")) value = fmtDate.format(new Date());
                }
                String fields[] = name.split(",");

                try {
                    switch (fields.length) {
                        case 1:
                            setColumn(fields[0], fields[0]);
                            break;
                        case 2:
                            setColumn(fields[0], fields[1]);
                            break;
                        default:
                            throw new IOException();
                    }
                } catch (SQLException ex) {
                    throw new SQLException("In column map " + file.getName() + " at line " + count + '-' + ex.getMessage());
                }
                if (value != null) {
                    if (value.toLowerCase().startsWith("!date:")) {
                        String fmt[] = value.split(":", 2);

                        setInputFormat(columns.size() - 1, FormatType.Date, fmt[1]);
                    } else {
                        setDefault(columns.size() - 1, value);
                    }
                }
            }
        }
        cols.close();
    }
    public void setDefault(int index, String value) {
        columns.get(index).defValue = value;
    }
    public void setInputFormat(int index, FormatType type, String value) {
        Column c = columns.get(index);

        c.formatType = type;
        c.inFormat   = value;

        if (type.isDate() && firstTimeField == -1) firstTimeField = index;
    }
    public java.sql.Timestamp getMinTimestamp(int index) {
        return index == -1? null : columns.get(index).getMinTime();
    }
    public java.sql.Timestamp getMaxTimestamp(int index) {
        return index == -1? null : columns.get(index).getMaxTime();
    }
    public java.sql.Timestamp getMinTimestamp() {
        return getMinTimestamp(firstTimeField);
    }
    public java.sql.Timestamp getMaxTimestamp() {
        return getMaxTimestamp(firstTimeField);
    }
    public String getColumnName(int index) {
        return columns.get(index).name;
    }
    public void addRow() throws SQLException {
        insert.moveToInsertRow();
        
        for (Column c : columns) {
            if (c.defValue != null) c.setValue(c.defValue);
        }
    }
    public void setValue(int index, String value) throws SQLException {
        if (index >= columns.size()) log.fatalError("No column with index " + index + " defined for table " + table);
        
        columns.get(index).setValue(value);
    }
    public void insertRow() throws SQLException {
        insert.insertRow();
        rowCount++;
    }
    public void close() {

    }
}
